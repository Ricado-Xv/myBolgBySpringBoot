package com.my.blog.blogdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlogDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
